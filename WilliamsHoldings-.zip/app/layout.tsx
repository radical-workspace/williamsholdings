import './globals.css';
export const metadata={title:'WilliamsHoldings',description:'Banking app'};
export default function Root({children}:{children:React.ReactNode}){return(<html lang="en"><body><div className="max-w-md mx-auto min-h-screen">{children}</div></body></html>);}
