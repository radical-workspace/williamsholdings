import { sbServer } from '@/lib/supabase/server';
export default async function Dashboard(){
  const sb=sbServer(); const { data:{ user } } = await sb.auth.getUser();
  let balance=0, acct='••••••••', currency='USD', status='Inactive';
  if(user){
    const { data } = await sb.from('accounts').select('available_balance,account_number,currency').eq('user_id',user.id).limit(1).maybeSingle();
    if(data){ balance=Number(data.available_balance||0); acct=data.account_number||acct; currency=data.currency||currency; }
  }
  const masked = acct.length>=4 ? `${acct.slice(0,4)}••••${acct.slice(-2)}` : acct;
  return (<div className="space-y-4">
    <div className="card"><div className="text-sm text-slate-600">Available balance</div>
      <div className="text-4xl font-bold">{new Intl.NumberFormat('en-US',{style:'currency',currency}).format(balance)}</div></div>
    <div className="card flex items-center justify-between"><div><div className="text-sm text-slate-600">Account</div><div className="font-medium">{masked}</div></div>
      <span className="px-3 py-1 rounded-full text-sm bg-slate-100 text-slate-700">{status}</span></div>
    <div className="grid grid-cols-2 gap-3">
      <a href="/deposit" className="card text-center">Deposit</a>
      <a href="/withdraw" className="card text-center">Withdraw</a>
      <a href="/payout-methods" className="card text-center">Payout Methods</a>
      <a href="/profile" className="card text-center">Account Info</a>
    </div></div>);
}
