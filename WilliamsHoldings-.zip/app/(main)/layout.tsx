export default function MainLayout({children}:{children:React.ReactNode}){
  return (<div className="pb-20"><div className="p-4">{children}</div>
    <nav className="fixed bottom-0 left-0 right-0 bg-white border-t">
      <div className="max-w-md mx-auto grid grid-cols-4 text-center">
        <a className="p-3" href="/dashboard">Home</a>
        <a className="p-3" href="/stats">Stats</a>
        <a className="p-3" href="/cards">Cards</a>
        <a className="p-3" href="/profile">Profile</a>
      </div>
    </nav></div>);
}
