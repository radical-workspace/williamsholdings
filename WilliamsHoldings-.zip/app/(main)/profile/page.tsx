import { sbServer } from '@/lib/supabase/server';
export default async function P(){ const sb=sbServer(); const { data:{ user } } = await sb.auth.getUser();
return <div className='space-y-4'><div className='card'><div className='text-sm text-slate-600'>Email</div><div className='font-medium'>{user?.email}</div></div><a className='btn btn-primary block text-center' href='/auth/pin-setup'>Change PIN</a></div>
}
