import { NextRequest, NextResponse } from 'next/server';
export function middleware(req: NextRequest){
  const { nextUrl, cookies, headers } = req;
  const p = nextUrl.pathname;
  if (p.startsWith('/auth') || p.startsWith('/api') || p.startsWith('/_next') || p === '/favicon.ico') return NextResponse.next();
  const host = headers.get('host') || '';
  if (host.includes('v0.app') || host.includes('usercontent.net')) return NextResponse.next();
  const has = cookies.has('sb-access-token') || cookies.has('sb-access-token.sig') || cookies.has('supabase-auth-token');
  if (!has) { const to=new URL('/auth/sign-in', nextUrl.origin); to.searchParams.set('redirectedFrom', p); return NextResponse.redirect(to); }
  const pinOK = cookies.get('pin_verified')?.value === 'true';
  if (!pinOK) { const to=new URL('/auth/pin', nextUrl.origin); to.searchParams.set('redirectedFrom', p); return NextResponse.redirect(to); }
  return NextResponse.next();
}
export const config = { matcher: ['/((?!_next|.*\.(?:png|jpg|svg|ico|css|js|map|txt)).*)'] };
