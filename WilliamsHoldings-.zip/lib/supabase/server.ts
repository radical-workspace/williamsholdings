import { cookies } from 'next/headers';
import { createServerClient, type CookieOptions } from '@supabase/ssr';
export function sbServer(){
  const url=process.env.NEXT_PUBLIC_SUPABASE_URL; const anon=process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;
  if(!url||!anon) throw new Error('Supabase env vars missing.');
  const c=cookies();
  return createServerClient(url, anon, { cookies:{
    get:(n:string)=>c.get(n)?.value,
    set:(n:string,v:string,o:CookieOptions)=>c.set({name:n,value:v,...o}),
    remove:(n:string,o:CookieOptions)=>c.set({name:n,value:'',...o,maxAge:0})
  }});
}
export async function getServerUser(){ const sb=sbServer(); const {data:{user}}=await sb.auth.getUser(); return user; }
